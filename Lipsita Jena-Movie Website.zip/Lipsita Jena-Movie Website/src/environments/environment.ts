

export const environment = {
  production: false,
  baseURL:"https://633fb414e44b83bc73bf8cf8.mockapi.io/Movie",
};

