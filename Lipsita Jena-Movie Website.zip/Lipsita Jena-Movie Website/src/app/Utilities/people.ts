export class people{
   name:String='';
   email:String='';
   noOfTickets:Number=0;
   time:String='';
   id:Number=0;
   movieName:String='';
   duration:String='';
   price:String='';
   remainingTickets:Number=0;
}