export class Movies{

    id:number=0;
    description:String='';
    name:String='';
    Price:String='';
    Tickets:number=0;
    Duration:String='';
    Image:String='';
    Desc2:String='';

}

